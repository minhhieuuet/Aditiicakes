<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class products extends Model
{
    //
    protected $table="products";

    public function typeproducts()
    {
    	return $this->belongsTo('App\TypeProducts','id_type','id');
    }
}
